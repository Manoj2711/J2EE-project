package com.cdac.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "booking")
public class Booking {
	
	@Id
	@GeneratedValue
	private int bookingId;
	private String productName;
	private int qty;
	private String custName;
	private String email;
	private int mobile;
	private String address;
	private int custId;
	
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public Booking(int bookingId) {
		super();
		this.bookingId = bookingId;
	}


//
//	public Booking(int custId) {
//		super();
//		this.custId = custId;
//	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	@Override
	public String toString() {
		return bookingId + " " + productName + " " + qty + " "
				+ custName + " " + email + " " + mobile + " " + address + " " + custId;
	}
	
	
	
	
	
	

}
