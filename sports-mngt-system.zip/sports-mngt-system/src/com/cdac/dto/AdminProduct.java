package com.cdac.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "adminproduct")
public class AdminProduct {
	
	@Id
	@GeneratedValue
	private int productId;
	private String productName;
	private String productType;
	private String sportsType;
	private int quantity;
	private float price;
	public AdminProduct() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public AdminProduct(int productId) {
		super();
		this.productId = productId;
	}


	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getSportsType() {
		return sportsType;
	}
	public void setSportsType(String sportsType) {
		this.sportsType = sportsType;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return productId + " " + productName + " " + productType
				+ " " + sportsType + " " + quantity + " " + price;
	}
	
	
	
	

}
