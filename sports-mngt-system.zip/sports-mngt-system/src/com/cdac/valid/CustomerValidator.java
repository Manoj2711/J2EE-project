package com.cdac.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cdac.dto.Customer;


@Service
public class CustomerValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Customer.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"email","emKey"," email is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"custPass","passKey","password required");
		
		Customer customer = (Customer)target;
		if(customer.getCustPass()!=null) {
			if(customer.getCustPass().length()<3) { 
				errors.rejectValue("custPass", "passKey", "password should contain more than 2 chars");
			}
		}
		
		
	}

}
