package com.cdac.dao;

import java.util.List;

import com.cdac.dto.AdminProduct;

public interface AdminProductDao {
	void insertProduct(AdminProduct admin);
	void deleteProduct(int productId);
	AdminProduct selectProduct(int productId);
	void updateProduct(AdminProduct admin);
	List<AdminProduct> selectAll();
}
