package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Booking;

public interface BookingDao {
	
	void addBooking(Booking book);
	
	List<Booking> selectAll(int custId);
	
	void deleteProduct(int bookingId);
	
	

}
