package com.cdac.dao;

import com.cdac.dto.Admin;

public interface AdminDao {
	boolean checkAdmin(Admin admin);
}
