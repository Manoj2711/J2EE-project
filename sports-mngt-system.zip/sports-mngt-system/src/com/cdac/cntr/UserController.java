 package com.cdac.cntr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.dto.AdminProduct;
import com.cdac.service.AdminProductService;

@Controller
public class UserController {

	@Autowired
	private AdminProductService adminproductservice;
	
	@RequestMapping(value = "/customer_list.htm",method = RequestMethod.GET)
	public String allProductList(ModelMap map) {
		List<AdminProduct> li = adminproductservice.selectAll();
		map.put("productList", li);
		return "cutomer_list";	

	}
}
