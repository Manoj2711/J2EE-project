package com.cdac.cntr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.AdminProduct;
import com.cdac.service.AdminProductService;

@Controller
public class AdminProductController {
	
	@Autowired
	private AdminProductService adminproductservice;
	
	@RequestMapping(value = "/prep_admin_add_form.htm",method = RequestMethod.GET)
	public String prepAdminProductAddForm(ModelMap map) {
		map.put("adminproduct", new AdminProduct());
		
		return "admin_proadd_form";
		
	}
	
	@RequestMapping(value = "/Adminproduct_add.htm",method = RequestMethod.POST)
	public String AdminProductAdd(AdminProduct admin,ModelMap map) {
		
		adminproductservice.addProduct(admin);;
		return "home2";
		
	}
	
	@RequestMapping(value = "/admin_product_list.htm",method = RequestMethod.GET)
	public String allProductList(ModelMap map) {
		List<AdminProduct> li = adminproductservice.selectAll();
		map.put("productList", li);
		return "admin_product_list";	

	}
	
	@RequestMapping(value = "/product_delete.htm",method = RequestMethod.GET)
	public String deleteProduct(@RequestParam int productId,ModelMap map) {
		
		adminproductservice.removeProduct(productId);
		
		List<AdminProduct> li = adminproductservice.selectAll();
		map.put("productList", li);
		return "admin_product_list";	

	}
	
	@RequestMapping(value = "/product_update_form.htm",method = RequestMethod.GET)
	public String updateProductForm(@RequestParam int productId,ModelMap map) {
		
		AdminProduct pro = adminproductservice.findProduct(productId);
		map.put("adminproduct", pro);
		
		return "admin_product_update_form";	

	}
	
	@RequestMapping(value = "/updateproduct_add.htm",method = RequestMethod.POST)
	public String updateProductAdd(AdminProduct admin,ModelMap map) {
		
		adminproductservice.modifyProduct(admin);
		
		List<AdminProduct> li = adminproductservice.selectAll();
		map.put("productList", li);
		return "admin_product_list";	
	}
	
	
	
}
