package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.AdminProduct;
import com.cdac.dto.Booking;
import com.cdac.dto.Customer;
import com.cdac.service.BookingService;

@Controller
public class BookingController {
	
	@Autowired
	private BookingService bookService;
	
	
	@RequestMapping(value = "/prep_booking_add_form.htm",method = RequestMethod.GET)
	public String prepBuyProductForm(ModelMap map) {
		
		map.put("booking", new Booking());
		
		return "booking_form";
		
	}
	
	@RequestMapping(value = "/book_add.htm",method = RequestMethod.POST)
	public String buyProductAdd(Booking book,ModelMap map,HttpSession session) {
		
		Customer cm = (Customer)session.getAttribute("customer");
		int custId = cm.getCustId();
		book.setCustId(custId);
		bookService.addBooking(book);
		return "CustomerWelcome";
		
	}
	
	@RequestMapping(value = "/order_list.htm",method = RequestMethod.GET)
	public String selectViewBook(ModelMap map,HttpSession session) {
		
		Customer cm = (Customer)session.getAttribute("customer");
		int custId = cm.getCustId();
		
		List<Booking> li=bookService.selectAll(custId);
		map.put("booklist",li);
		
		return "order_detail";
		
	}
	
	@RequestMapping(value = "/booking_delete.htm",method = RequestMethod.GET)
	public String deleteBooking(@RequestParam int bookingId) {
		
		bookService.removeProduct(bookingId);
	
		return "CustomerWelcome";	

	}
	
	

}
