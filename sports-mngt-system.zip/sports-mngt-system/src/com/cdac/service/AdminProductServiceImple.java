package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.AdminProductDao;
import com.cdac.dto.AdminProduct;

@Service
public class AdminProductServiceImple implements AdminProductService {
     
	@Autowired
	private AdminProductDao adminDao;
	
	@Override
	public void addProduct(AdminProduct admin) {
		adminDao.insertProduct(admin);
		
	}

	@Override
	public void removeProduct(int productId) {
		
		adminDao.deleteProduct(productId);
	}

	@Override
	public AdminProduct findProduct(int productId) {
		
		return adminDao.selectProduct(productId);
	}

	@Override
	public void modifyProduct(AdminProduct admin) {
		
		adminDao.updateProduct(admin);
	}

	@Override
	public List<AdminProduct> selectAll() {
		
		return adminDao.selectAll();
	}

}
