package com.cdac.service;

import java.util.List;

import com.cdac.dto.Booking;


public interface BookingService {
	
    void addBooking(Booking book);
	
	List<Booking> selectAll(int custId);
	
	void removeProduct(int bookingId);
}
