package com.cdac.service;

import java.util.List;

import com.cdac.dto.AdminProduct;

public interface AdminProductService {
	
	void addProduct(AdminProduct admin);
	void removeProduct(int productId);
	AdminProduct findProduct(int productId);
	void modifyProduct(AdminProduct admin);
	List<AdminProduct> selectAll();

}
