package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.BookingDao;
import com.cdac.dto.Booking;

@Service
public class BookingServiceImple implements BookingService{
	
	@Autowired
	private BookingDao bookingDao;

	@Override
	public void addBooking(Booking book) {
		bookingDao.addBooking(book);
		
	}

	@Override
	public List<Booking> selectAll(int custId) {
		
		return bookingDao.selectAll(custId);
	}

	@Override
	public void removeProduct(int bookingId) {
		
		bookingDao.deleteProduct(bookingId);
	}

}
