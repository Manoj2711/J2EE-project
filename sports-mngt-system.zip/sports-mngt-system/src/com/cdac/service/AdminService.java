package com.cdac.service;

import com.cdac.dto.Admin;

public interface AdminService {
	
	boolean checkAdmin(Admin admin);

}
